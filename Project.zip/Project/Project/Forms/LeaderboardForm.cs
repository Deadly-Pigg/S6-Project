﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Reflection;

namespace Project
{

    public partial class LeaderboardForm : Form
    {
        List<StoreData> lbData = new List<StoreData>(); //List used to store each individual row from the database
        int sortBoard = 0; //Necessary for changing how the leaderboard is sorted

        public LeaderboardForm() 
        {
            InitializeComponent();
            FetchData();
        }
        private void FetchData() //Fetches the data from the database and stores it in the program.
        {
            OleDbDataReader SQLRead;
            string connect = "Provider=Microsoft.Jet.OLEDB.4.0;";
            string fileLoc = @"Data Source=.\ProjectDB.mdb";
            OleDbConnection conn = new OleDbConnection(connect + fileLoc);
            conn.Open(); 
            
            try { //Queries the database, and stores it into the lbData list. try is used just in case this crashes the program.
                string query = @"Select * FROM LeaderBoard";
                OleDbCommand command = new OleDbCommand(query, conn);
                SQLRead = command.ExecuteReader();
                if (SQLRead.HasRows)
                {
                    while (SQLRead.Read())
                    {
                        StoreData temp = new StoreData(
                            Convert.ToString(SQLRead["userName"]),
                            Convert.ToInt32(SQLRead["score"]),
                            Convert.ToDouble(SQLRead["accuracy"]),
                            Convert.ToString(SQLRead["difficulty"]),
                            Convert.ToBoolean(SQLRead["movement"])
                            );
                        lbData.Add(temp);
                    }
                }
                else
                { 
                    MessageBox.Show("No data is stored in the database."); 
                }
                lbData.Reverse();
            }
            catch (Exception ex) //Displays the error responsible for the leaderboard not displaying the information.
            { 
            MessageBox.Show("Error has occured in loading the leaderboard, and so data cannot be displayed:\n" + ex.Message); 
            }
            conn.Close();
        }

     
        private void DisplayData() //Takes the data out of the lbData list, and displays them in columns.
        {
            Leaderboard.Items.Clear();
            foreach (StoreData temp in lbData)
            {
                ListViewItem item = new ListViewItem(temp.getName());
                item.SubItems.Add(Convert.ToString(temp.getScore()));
                item.SubItems.Add(Convert.ToString(temp.getAcc()) + "%");
                item.SubItems.Add(temp.getDiff());
                item.SubItems.Add(Convert.ToString(temp.getMove()));
                Leaderboard.Items.Add(item);
            }
        }
        private void Sort_Click(object sender, EventArgs e) //Sorts the leaderboard in one of two ways. [sortboard is odd, Score descending; otherwise, Accuracy descending]
        {
            List<double> passVal = new List<double>();
            switch (sortBoard % 2)
            {
                case (0):
                    {
                        foreach (StoreData i in lbData)
                        { passVal.Add(i.getScore()); }
                        label1.Text = "Leaderboard: Highest Score";
                        break;
                    }
                case (1):
                    {
                        foreach (StoreData i in lbData)
                        { passVal.Add(i.getAcc()); }
                        label1.Text = "Leaderboard: Highest Accuracy";
                        break;
                    }
            }
            SortVal(passVal.ToArray());
            passVal.Clear();
            sortBoard++;
        }
        private void SortVal(double[] array) //Insertion sort. Responsible for sorting the leaderboard.
        {
            for (int i = 0; i < lbData.Count(); i++)
            {
                int i2 = i;
                double temp = array[i2];
                StoreData temp2 = lbData.ElementAt(i2);
                while (i2 > 0 && array[i2 - 1] < temp)
                {
                    lbData.RemoveAt(i2);
                    lbData.Insert(i2, lbData.ElementAt(i2 - 1));
                    array[i2] = array[i2 - 1];
                    i2--;
                }
                array[i2] = temp;
                lbData.RemoveAt(i2);
                lbData.Insert(i2, temp2);
            }
            DisplayData();
        }


        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
