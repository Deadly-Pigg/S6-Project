﻿namespace Project
{
    partial class LeaderboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Sort = new System.Windows.Forms.Button();
            this.CloseButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Leaderboard = new System.Windows.Forms.ListView();
            this.UserCol = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ScoreCol = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AccuracyCol = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DifficultyCol = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.MovementCol = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // Sort
            // 
            this.Sort.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Sort.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Sort.Location = new System.Drawing.Point(772, 12);
            this.Sort.Name = "Sort";
            this.Sort.Size = new System.Drawing.Size(195, 105);
            this.Sort.TabIndex = 1;
            this.Sort.Text = "Sort Leaderboard";
            this.Sort.UseVisualStyleBackColor = true;
            this.Sort.Click += new System.EventHandler(this.Sort_Click);
            // 
            // CloseButton
            // 
            this.CloseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.CloseButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.CloseButton.Location = new System.Drawing.Point(12, 465);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(222, 65);
            this.CloseButton.TabIndex = 3;
            this.CloseButton.Text = "Close Leaderboard";
            this.CloseButton.UseVisualStyleBackColor = true;
            this.CloseButton.Click += new System.EventHandler(this.Close_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(342, 91);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(140, 26);
            this.label1.TabIndex = 4;
            this.label1.Text = "Leaderboard:";
            // 
            // Leaderboard
            // 
            this.Leaderboard.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.UserCol,
            this.ScoreCol,
            this.AccuracyCol,
            this.DifficultyCol,
            this.MovementCol});
            this.Leaderboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Leaderboard.HideSelection = false;
            this.Leaderboard.Location = new System.Drawing.Point(342, 130);
            this.Leaderboard.Name = "Leaderboard";
            this.Leaderboard.Size = new System.Drawing.Size(625, 400);
            this.Leaderboard.TabIndex = 5;
            this.Leaderboard.UseCompatibleStateImageBehavior = false;
            this.Leaderboard.View = System.Windows.Forms.View.Details;
            // 
            // UserCol
            // 
            this.UserCol.Tag = "";
            this.UserCol.Text = "Username";
            this.UserCol.Width = 200;
            // 
            // ScoreCol
            // 
            this.ScoreCol.Text = "Score";
            this.ScoreCol.Width = 110;
            // 
            // AccuracyCol
            // 
            this.AccuracyCol.Text = "Accuracy";
            this.AccuracyCol.Width = 110;
            // 
            // DifficultyCol
            // 
            this.DifficultyCol.Text = "Difficulty";
            this.DifficultyCol.Width = 100;
            // 
            // MovementCol
            // 
            this.MovementCol.Text = "Movement";
            this.MovementCol.Width = 100;
            // 
            // LeaderboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(979, 542);
            this.Controls.Add(this.Leaderboard);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.Sort);
            this.Name = "LeaderboardForm";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Sort;
        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView Leaderboard;
        private System.Windows.Forms.ColumnHeader UserCol;
        private System.Windows.Forms.ColumnHeader ScoreCol;
        private System.Windows.Forms.ColumnHeader AccuracyCol;
        private System.Windows.Forms.ColumnHeader DifficultyCol;
        private System.Windows.Forms.ColumnHeader MovementCol;
    }
}