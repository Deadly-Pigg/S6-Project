﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Form1 : Form
    {

        Random rand = new Random();
        List<PictureBox> items = new List<PictureBox>();
        List<int[]> movement = new List<int[]>();
        int miss, hit, blunder, timer;
        public Form1()
        {
            InitializeComponent();
            this.PlayArea.Click += missCheck;
        }
        private void Start_Click(object sender, EventArgs e)
        {
            this.gameTick.Start();
            this.Start.Enabled = false;
            this.Difficulty.Enabled = false;
            this.spawnRate.Start();
        }
        private void MakePictureBox()
        {
            int i = rand.Next(0, 2);
            var xMov = 0;
            PictureBox newPic = new PictureBox();
            int[] movCord = new int[2] { rand.Next(-2, 2), rand.Next(-2, 2) };
            movement.Add(movCord);
            newPic.Height = 30;
            newPic.Width = 30;
            int x = rand.Next(0, PlayArea.ClientSize.Width - newPic.Width)+13;
            int y = rand.Next(0, PlayArea.ClientSize.Height - newPic.Height) + 13;
            newPic.Location = new Point(x, y);
            items.Add(newPic);
            this.Controls.Add(newPic);
            this.Controls.SetChildIndex(newPic, 0);

            if (i != 0)
            {
                newPic.BackColor = Color.Blue;
                newPic.Click += Hit;
                xMov += 20;
            }
            else
            {
                newPic.BackColor = Color.Red;
                newPic.Click += Blunder;
            }
        }
        private void Hit(object sender, EventArgs e)
        {
            PictureBox temPic = sender as PictureBox;
            int removeIndex = items.IndexOf(temPic);
            items.Remove(temPic);
           .RemoveAt(removeIndex);
            this.Controls.Remove(temPic);
            hit++;
            ItemCount.Text = "I'ems: " + items.Count();
            Hits.Text = "Hits: " + hit;
        }

        

        private void Leaderboard_Click(object sender, EventArgs e)
        {
            Form2 lb = new Form2();
            lb.Show();
        }

        private void spawnRate_Tick(object sender, EventArgs e)
        {
            if(items.Count < 10)
            {
                MakePictureBox();
            }
            else { }
        }

        private void Blunder(object sender, EventArgs e)
        {
            PictureBox temPic = sender as PictureBox;
            int removeIndex = items.IndexOf(temPic);
            items.Remove(temPic);
            items.RemoveAt(removeIndex);
            blunder++;
            this.Controls.Remove(temPic);
            ItemCount.Text = "I'ems: " + items.Count();
            Blunders.Text = "Blunders: " + blunder;
        }

        private void game_Tick(object sender, EventArgs e)
        {
            bool check = true;
            PictureBox[] itemArray = items.ToArray();
            int[][] cordArray = movement.ToArray();
            int itemAmount = itemArray.Length;
            for (int i = 0; i < itemAmount; i++)
            {
                int Douglas = itemArray[i].Location.X;
                int Col = itemArray[i].Location.Y;

                if (Douglas <= 13 || Douglas >= PlayArea.Width)
                {
                    cordArray[i][0] *= -1;
                    Douglas += Douglas <= 13 ? 10 : -10;
                }
                if(Col <= 13 || Col >= PlayArea.Height)
                {
                    cordArray[i][1] *= -1;
                    Col += Col <= 13 ? 10 : -10;
                }
                Douglas += cordArray[i][0];
                Col += cordArray[i][1];
                itemArray[i].Location = new Point(Douglas, Col);
                gameTick.Interval = (10 / (itemAmount / 10 > 1 ? itemAmount/10 : 1)) + 1;
                //movement = cordArray.ToList();
            }
        }
        private void missCheck(object sender, EventArgs e)
        {
            if (gameTick.Enabled == true)
            {
                miss++;
                Misses.Text = "Misses: " + miss;
            }
        }

        private void Difficulty_Click(object sender, EventArgs e)
        {
            System.Drawing.Size size = new System.Drawing.Size(500, 280);
            Form inputBox = new Form();
            string input = "";

            inputBox.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            inputBox.ClientSize = size;
            inputBox.Text = "Name";

            RadioButton diff1 = new RadioButton();
            diff1.Name = "difficulty";
            diff1.Size = new System.Drawing.Size(75, 23);
            diff1.Text = "&Difficulty 1";
            diff1.Location = new System.Drawing.Point(20, 39);
            inputBox.Controls.Add(diff1);

            RadioButton diff2 = new RadioButton();
            diff2.Name = "difficulty";
            diff2.Size = new System.Drawing.Size(75, 23);
            diff2.Text = "&Difficulty 2";
            diff2.Location = new System.Drawing.Point(20, 69);
            inputBox.Controls.Add(diff2);

            RadioButton diff3 = new RadioButton();
            diff3.Name = "difficulty";
            diff3.Size = new System.Drawing.Size(75, 23);
            diff3.Text = "&Difficulty 3";
            diff3.Location = new System.Drawing.Point(20, 99);
            inputBox.Controls.Add(diff3);

            CheckBox movement = new CheckBox();
            movement.Name = "movement";
            movement.Size = new System.Drawing.Size(150, 23);
            movement.Text = "&can boxes move?";
            movement.Location = new System.Drawing.Point(20, 129);
            inputBox.Controls.Add(movement);

            Button confirmButton = new Button();
            confirmButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            confirmButton.Name = "Exit";
            confirmButton.Size = new System.Drawing.Size(75, 23);
            confirmButton.Text = "&Exit";
            confirmButton.Location = new System.Drawing.Point(size.Width - 80, 39);
            inputBox.Controls.Add(confirmButton);
            inputBox.AcceptButton = confirmButton;


            DialogResult result = inputBox.ShowDialog();
            if (diff1.Checked == true)
            { Difficulty.Text = "Change Difficulty Current: Easy"; }
            else if (diff2.Checked == true)
            { Difficulty.Text = "Change Difficulty Current: Normal"; }
            else if (diff3.Checked == true)
            { Difficulty.Text = "Change Difficulty Current: Hard"; }
            if (movement.Checked == true)
            {
                Difficulty.Text += " + Movement";
            }
        }
    }
}
