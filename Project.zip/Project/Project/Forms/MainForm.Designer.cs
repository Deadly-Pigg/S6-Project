﻿namespace Project
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Hits = new System.Windows.Forms.Label();
            this.Misses = new System.Windows.Forms.Label();
            this.Blunders = new System.Windows.Forms.Label();
            this.GameTick = new System.Windows.Forms.Timer(this.components);
            this.PlayArea = new System.Windows.Forms.PictureBox();
            this.PlayerScore = new System.Windows.Forms.Label();
            this.Start = new System.Windows.Forms.Button();
            this.Difficulty = new System.Windows.Forms.Button();
            this.Leaderboard = new System.Windows.Forms.Button();
            this.SpawnRate = new System.Windows.Forms.Timer(this.components);
            this.HighScore = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PlayArea)).BeginInit();
            this.SuspendLayout();
            // 
            // Hits
            // 
            this.Hits.AutoSize = true;
            this.Hits.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Hits.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Hits.Location = new System.Drawing.Point(829, 188);
            this.Hits.Name = "Hits";
            this.Hits.Size = new System.Drawing.Size(74, 26);
            this.Hits.TabIndex = 2;
            this.Hits.Text = "Hits: 0";
            // 
            // Misses
            // 
            this.Misses.AutoSize = true;
            this.Misses.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Misses.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Misses.Location = new System.Drawing.Point(829, 214);
            this.Misses.Name = "Misses";
            this.Misses.Size = new System.Drawing.Size(104, 26);
            this.Misses.TabIndex = 3;
            this.Misses.Text = "Misses: 0";
            // 
            // Blunders
            // 
            this.Blunders.AutoSize = true;
            this.Blunders.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Blunders.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Blunders.Location = new System.Drawing.Point(829, 240);
            this.Blunders.Name = "Blunders";
            this.Blunders.Size = new System.Drawing.Size(122, 26);
            this.Blunders.TabIndex = 4;
            this.Blunders.Text = "Blunders: 0";
            // 
            // GameTick
            // 
            this.GameTick.Interval = 10;
            this.GameTick.Tick += new System.EventHandler(this.Game_Tick);
            // 
            // PlayArea
            // 
            this.PlayArea.Image = global::Project.Properties.Resources.bruyhh;
            this.PlayArea.InitialImage = null;
            this.PlayArea.Location = new System.Drawing.Point(13, 13);
            this.PlayArea.Name = "PlayArea";
            this.PlayArea.Size = new System.Drawing.Size(810, 547);
            this.PlayArea.TabIndex = 5;
            this.PlayArea.TabStop = false;
            // 
            // PlayerScore
            // 
            this.PlayerScore.AutoSize = true;
            this.PlayerScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.PlayerScore.ForeColor = System.Drawing.SystemColors.ControlText;
            this.PlayerScore.Location = new System.Drawing.Point(829, 266);
            this.PlayerScore.Name = "PlayerScore";
            this.PlayerScore.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.PlayerScore.Size = new System.Drawing.Size(93, 26);
            this.PlayerScore.TabIndex = 6;
            this.PlayerScore.Text = "Score: 0";
            // 
            // Start
            // 
            this.Start.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Start.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Start.Location = new System.Drawing.Point(829, 12);
            this.Start.Name = "Start";
            this.Start.Size = new System.Drawing.Size(233, 65);
            this.Start.TabIndex = 7;
            this.Start.Text = "Start";
            this.Start.UseVisualStyleBackColor = true;
            this.Start.Click += new System.EventHandler(this.Start_Click);
            // 
            // Difficulty
            // 
            this.Difficulty.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Difficulty.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Difficulty.Location = new System.Drawing.Point(829, 83);
            this.Difficulty.Name = "Difficulty";
            this.Difficulty.Size = new System.Drawing.Size(233, 102);
            this.Difficulty.TabIndex = 8;
            this.Difficulty.Text = "Change Difficulty Current: Easy\r\n";
            this.Difficulty.UseVisualStyleBackColor = true;
            this.Difficulty.Click += new System.EventHandler(this.Difficulty_Click);
            // 
            // Leaderboard
            // 
            this.Leaderboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Leaderboard.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Leaderboard.Location = new System.Drawing.Point(834, 495);
            this.Leaderboard.Name = "Leaderboard";
            this.Leaderboard.Size = new System.Drawing.Size(233, 65);
            this.Leaderboard.TabIndex = 9;
            this.Leaderboard.Text = "Leaderboard";
            this.Leaderboard.UseVisualStyleBackColor = true;
            this.Leaderboard.Click += new System.EventHandler(this.Leaderboard_Click);
            // 
            // SpawnRate
            // 
            this.SpawnRate.Tick += new System.EventHandler(this.SpawnRate_Tick);
            // 
            // HighScore
            // 
            this.HighScore.AutoSize = true;
            this.HighScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.HighScore.Location = new System.Drawing.Point(829, 369);
            this.HighScore.Name = "HighScore";
            this.HighScore.Size = new System.Drawing.Size(0, 26);
            this.HighScore.TabIndex = 10;
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(1079, 578);
            this.Controls.Add(this.HighScore);
            this.Controls.Add(this.Leaderboard);
            this.Controls.Add(this.Difficulty);
            this.Controls.Add(this.Start);
            this.Controls.Add(this.PlayerScore);
            this.Controls.Add(this.PlayArea);
            this.Controls.Add(this.Blunders);
            this.Controls.Add(this.Misses);
            this.Controls.Add(this.Hits);
            this.Name = "MainForm";
            ((System.ComponentModel.ISupportInitialize)(this.PlayArea)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Hits;
        private System.Windows.Forms.Label Misses;
        private System.Windows.Forms.Label Blunders;
        private System.Windows.Forms.Timer GameTick;
        private System.Windows.Forms.PictureBox PlayArea;
        private System.Windows.Forms.Label PlayerScore;
        private System.Windows.Forms.Button Start;
        private System.Windows.Forms.Button Difficulty;
        private System.Windows.Forms.Button Leaderboard;
        private System.Windows.Forms.Timer SpawnRate;
        private System.Windows.Forms.Label HighScore;
    }
}

