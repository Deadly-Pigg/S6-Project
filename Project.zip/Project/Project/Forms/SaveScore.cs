﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class SaveScore : Form
    {
        double accuracyDiv = (MainForm.hit + MainForm.blunder + MainForm.miss); //Variables used for calculating the accuracy, with a bit of math.
        double accuracyHits = (MainForm.hit + MainForm.blunder) * 100;
        string diff = ""; //used for storing the difficulty, as it is sent as an integer from the MainForm.

        public SaveScore() //Displays the players stats after the game is over
        {
            InitializeComponent();

            accuracyDiv = accuracyDiv == 0 ? 1 : accuracyDiv; //This is for when the player suddenly decides they dont want to play anymore.
            switch (MainForm.difficulty)
            {
                case (1):
                    { diff = "Easy";
                        break; }
                case (2):
                    { diff = "Medium";
                        break; }
                case (3):
                    { diff = "Hard";
                        break; }
            }

            accuracyDiv = accuracyDiv == 0 ? 0 : accuracyDiv;
            label2.Text = "Final Score: " + MainForm.score +
                "\r\nAccuracy: " + Math.Round(accuracyHits/accuracyDiv,2) + "%" +
                "\r\nHits: " + MainForm.hit +
                "\r\nBlunders: " + MainForm.blunder +
                "\r\nMisses: " + MainForm.miss;
            label3.Text = "Difficulty Settings:" +
                "\r\nDifficulty: " + diff +
                "\r\nMovement: " + MainForm.movement;

            
        }

        private void SubmitScore_Click(object sender, EventArgs e) //Submit button. Saves the players score to the database if possible.
        {
            string str = textBox1.Text;
            bool valid = false;

            valid = InputValidation(str);
            if(valid == true)
            {
                OleDbDataReader SQLWrite;
                string connect = "Provider=Microsoft.Jet.OLEDB.4.0;";
                string fileLoc = @"Data Source=.\ProjectDB.mdb";
                OleDbConnection conn = new OleDbConnection(connect + fileLoc);
                conn.Open();
                try
                {
                    string query = @"INSERT INTO Leaderboard (userName, score, accuracy, difficulty, movement)
                                     VALUES ('" + str + "',"
                                     + MainForm.score + ","
                                     + Math.Round(accuracyHits / accuracyDiv, 2) + ", '"
                                     + diff + "', "
                                     + MainForm.movement + ");";

                    OleDbCommand command = new OleDbCommand(query, conn);
                    SQLWrite = command.ExecuteReader();
                    MessageBox.Show("Your data has been added to the table successfully");
                    conn.Close();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("an error occured, and your score has not been added to the database :(, because:\n" + ex);
                }
            }
        }
        private bool InputValidation(string str)
        {
            if (str.Length < 3 || str.Length > 16) //validates the inputted username. Ensures it is within a certain range.
            {
                MessageBox.Show("Name is outwith the range. Please enter a name between 3 and 16 chars");
                return false;
            }
            if(str.Trim() != str)
            {
                MessageBox.Show("Name is invalid; has leading and/or ending whitespace characters");
                return false;
            }
            if(Regex.IsMatch(str, @"[^\x20-\x7F]") == true)
            {
                MessageBox.Show("Name contains illegal characters. Remove any non-ASCII values");
                return false;
            }
            return true;
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
