﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Threading;

namespace Project
{

    public partial class MainForm : Form
    {
        List<BoxSettings> boxSettings = new List<BoxSettings>(); //List of BoxSettings
        Random rand = new Random();

        public static int miss, hit, blunder, timer, difficulty = 1; //Variables that are transferred between Form(s)
        public static double score;
        public static bool movement = false;

        bool isOpen;
        int highScore;
        public MainForm()
        {
            InitializeComponent();
            this.PlayArea.Click += MissCheck; //Checks if the user clicked the PlayArea during the game.
        }
        private void Start_Click(object sender, EventArgs e) /*Starts the game, resetting all values back to their initial state (that are supposed to be reset)*/
        {
            this.SpawnRate.Interval = 750;
            this.SpawnRate.Start();
            this.GameTick.Start();
            miss = 0;
            hit = 0;
            blunder = 0;
            timer = 0;
            score = 0;
            isOpen = false;
            Blunders.Text = "Blunders: " + blunder;
            Hits.Text = "Hits: " + hit;
            PlayerScore.Text = "Score: " + score;
            Misses.Text = "Misses: " + miss;
            this.Difficulty.Enabled = false;
            this.Start.Enabled = false;
        }
        private void MakePictureBox() //Creates clickable pictureboxes, their life duration, where they'll move and adds them to a List called boxSettings.
            //pictureBoxes List is necessary as Clicked has code that doesn't work properly otherwise.
        {
            PictureBox newPic = new PictureBox();
            newPic.Height = 60 - difficulty*15;
            newPic.Width = 60 - difficulty*15;
            int x = rand.Next(0, PlayArea.ClientSize.Width - newPic.Width)+10;
            int y = rand.Next(0, PlayArea.ClientSize.Height - newPic.Height) + 10;
            newPic.Location = new Point(x, y);

            BoxSettings tempBoxData = new BoxSettings(newPic);
            boxSettings.Add(tempBoxData);
            this.Controls.Add(newPic);
            this.Controls.SetChildIndex(newPic, 0);

            if (rand.Next(0,3) != 0)
            {
                newPic.BackColor = Color.FromArgb(0,0,rand.Next(50,256));
            }
            else
            {
                newPic.BackColor = Color.FromArgb(rand.Next(50, 256),0,0);
            }
            newPic.Click += Clicked;
        }


        private void SpawnRate_Tick(object sender, EventArgs e) /*Spawns the clickable boxes a set amount of times, and stops doing so after
        after the game session is over */
        {
            int spawnAmount = 100;

            if (timer < spawnAmount)
            {
                MakePictureBox();
            }
            else if (boxSettings.Count() == 0 && isOpen == false) //Displays the game over screen (SaveScore form)
            {
                ScoreCount();
                isOpen = true;
                GameEnd();
            }
            timer++;
        }
        private void Game_Tick(object sender, EventArgs e)
        {
            List<BoxSettings> boxRemove = new List<BoxSettings>(); //Saves boxes for removal. Necessary as the program crashes otherwise.]

            foreach (BoxSettings box in boxSettings)
            {
                if (box.GetLife().Elapsed.TotalMilliseconds >= 3000) // Despawns the boxes
                {
                    boxRemove.Add(box);
                }
                else if (box.GetLife().Elapsed.TotalMilliseconds >= 1500 && box.GetPicture().BackColor.R == 0) // Changes good blue boxes into bad red boxes.
                                                                                                               //Hope you aren't colourblind!
                {
                    box.GetPicture().BackColor = Color.FromArgb(box.GetPicture().BackColor.B, 0, 0);
                }
                if (movement == true) //If movement was enabled in the difficulty choice form, this is responsible for applying movement to said boxes.
                {
                    int X = box.GetPicture().Location.X;
                    int Y = box.GetPicture().Location.Y;
                    if (X <= 13 || X >= PlayArea.Width - box.GetPicture().Width)
                    {
                        box.GetMoves()[0] *= -1;
                        X += X <= 13 ? 10 : -10;
                    }
                    if (Y <= 13 || Y >= PlayArea.Height - box.GetPicture().Height)
                    {
                        box.GetMoves()[1] *= -1;
                        Y += Y <= 13 ? 10 : -10;
                    }

                    box.GetPicture().Location = new Point(X += box.GetMoves()[0], Y += box.GetMoves()[1]);
                }
            }
           
            foreach (BoxSettings box in boxRemove) //Removes flagged boxes from the game.
            {
                try //Athough extremely unlikely, the program will crash if it tries to remove an item from the list that doesn't exist. This stops the crashing.
                {
                    boxSettings.Remove(box);
                    this.Controls.Remove(box.GetPicture());
                }
                catch { Console.WriteLine("Program tried to remove an item that doesn't exist."); }
            }

            boxRemove.Clear();
        }


        private void Clicked(object sender, EventArgs e) //Checks if the user clicked box and then removes it.
        {
            PictureBox temPic = sender as PictureBox;
            int i = 0;

            foreach(BoxSettings box in boxSettings)
            {
                if(box.GetPicture() == temPic)
                {
                    i = boxSettings.IndexOf(box);
                    break;
                }
            }

            boxSettings.RemoveAt(i);
            this.Controls.Remove(temPic);

            if (temPic.BackColor.R == 0) //Checks the type of box that was clicked
            {
                hit++;
                Hits.Text = "Hits: " + hit;
            }
            else
            {
                blunder++;
                Blunders.Text = "Blunders: " + blunder;
            }
            ScoreCount();
        }
        private void MissCheck(object sender, EventArgs e) //Miss counter. Only runs when a game instance is running
        {
            if (Start.Enabled == false)
            {
                miss++;
                Misses.Text = "Misses: " + miss;
                ScoreCount();
            }

        }
        private void ScoreCount() //Calculates the score, movement enabled multiplies score by 1.5, difficulty multiplies it by (0.5, 1, 1.5).
        {
            double bonus = movement == true ? 1.5 : 1;
            score = (hit * 100 - blunder * 100 - miss * 10) * ((double)difficulty/2);
            score *= bonus;
            double scoreDisplay = Math.Round(score) <= 0 ? 0 : Math.Round(score); //Ensures displayed score is never less than 0.
            PlayerScore.Text = "Score: " + scoreDisplay;
        }


        
        private void Leaderboard_Click(object sender, EventArgs e) //Creates a new instance of the LeaderboardForm
        {
            LeaderboardForm lb = new LeaderboardForm();
            lb.Show();
            this.Leaderboard.Enabled = false;

            lb.FormClosed += Lb_FormClosed;
        }
        private void Lb_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Leaderboard.Enabled = true;
        }



        private void Difficulty_Click(object sender, EventArgs e) //Creates a dialogbox of the DifficultyChoice form
        {
            DifficultyChoice difficultyDialog = new DifficultyChoice();
            difficultyDialog.ShowDialog();
            DifficultyDialog_FormClosed();
        }
        private void DifficultyDialog_FormClosed() // Assigns values to the variables required to change the difficulty of the game after the DifficultyChoice form is closed.
        {
            string temp = "";
            difficulty = DifficultyChoice.difficulty; //Sent from the DifficultyChoice form.
            movement = DifficultyChoice.movement;

            switch (difficulty)
            {
                case (1):
                    { temp = "Easy";
                        break;}
                case (2):
                    { temp = "Medium";
                        break; }
                case (3):
                    { temp = "Hard";
                        break; }
            }
            temp += movement == true ? " + Movement" : "";
            Difficulty.Text = "Change Difficulty\n\rCurrent: " + temp;
        }



        private void GameEnd() //Occurs after the game ends, prompts the user to input their score through the SaveScore form whilst also displaying the high score
        {
            score = Math.Round(score) <= 0 ? 0 : Math.Round(score);
            SaveScore inputScore = new SaveScore();
            inputScore.ShowDialog();

            this.Start.Enabled = true;
            this.Difficulty.Enabled = true;

            highScore = (int)Math.Max(highScore, score);
            HighScore.Text = "High Score: " + highScore;
        }

    }
}
