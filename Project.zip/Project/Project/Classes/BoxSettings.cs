﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Threading;
using System.Diagnostics;

namespace Project
{
    public class BoxSettings
    {
        PictureBox items = new PictureBox();
        int[] moves = new int[2];
        Stopwatch lifeTime = new Stopwatch();

        public BoxSettings(PictureBox pic) //Constructor
        {
            Random rand = new Random(); //This code is to initialise the timer and movement of the box object.
            this.lifeTime.Start();
            this.moves[0] = rand.Next(-2, 2);
            this.moves[1] = rand.Next(-2, 2);

            this.items = pic; //Saves the data of a picturebox to this instance variable
        }

        public PictureBox GetPicture() //Methods for returning the values of certain instance variables of the object.
        {
            return this.items;
        }
        public int[] GetMoves()
        {
            return this.moves;
        }
        public Stopwatch GetLife()
        {
            return this.lifeTime;
        }
    }
}