﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    internal class StoreData
    {
        string Pname;
        int Pscore;
        double Paccuracy;
        string Pdifficulty;
        bool Pmovement;

        public StoreData(string n, int s, double a, string d, bool m) //Constructor
        {
            Pname = n;
            Pscore = s;
            Paccuracy = a;
            Pdifficulty = d;
            Pmovement = m;
        }

        public string getName() //Methods to fetch the data
        {
            return this.Pname;
        }
        public int getScore()
        {
            return this.Pscore;
        }
        public double getAcc()
        {
            return this.Paccuracy;
        }
        public string getDiff()
        {
            return this.Pdifficulty;
        }
        public bool getMove()
        {
            return this.Pmovement;
        }
    }
}
