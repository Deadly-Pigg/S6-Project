﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Project
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OleDbDataReader SQLRead;
            string connect = "Provider=Microsoft.Jet.OLEDB.4.0;";
            string fileLoc = @"Data Source=.\ProjectDB.mdb";
            OleDbConnection conn = new OleDbConnection(connect + fileLoc);
            conn.Open();

            try
            {
                string query = @"Select * FROM LeadrBoard
                                 ORDER BY userID DESC";
                OleDbCommand command = new OleDbCommand(query, conn);
                SQLRead = command.ExecuteReader();
                if (SQLRead.HasRows)
                {
                    while (SQLRead.Read())
                    {
                        listBox1.Items.Add(SQLRead["userID"] + " " + SQLRead["userName"] + " " + SQLRead["score"] + " " + SQLRead["accuracy"] + "% " + SQLRead["difficulty"] + " " + SQLRead["movement"]);
                    }
                }
                else
                {
                    listBox1.Items.Add("Nothing found");
                }
            }

            catch (Exception ex)
            {
                textBox1.Text = ex.Message;
            }
            
        }
    }
}
