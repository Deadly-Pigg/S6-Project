﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class DifficultyChoice : Form
    {
        public static int difficulty = 1; //Public variables
        public static bool movement = false;
        public DifficultyChoice() //Used for 'remembering' the old state of the DifficultyChoice form.
        {
            InitializeComponent();

            DifficultySlider.Value = MainForm.difficulty; 
            MoveChoice.Checked = MainForm.movement;

            ChangeSliderColour();
            ChangeCheckedColour();
        }


        private void Submit_Click(object sender, EventArgs e) //Assigns values to the public variables, and then closes this Form.
        {
            difficulty = DifficultySlider.Value;
            movement = MoveChoice.Checked;
            this.Close();
        }
        private void DifficultySlider_Scroll(object sender, EventArgs e) 
        {
            ChangeSliderColour();
        }
        private void MoveChoice_CheckedChanged(object sender, EventArgs e)
        {
            ChangeCheckedColour();
        }


        private void ChangeSliderColour() //Used for aesthetics, same with the function below. Changes the colour of the slider so it highlights when selected.
        {
            label1.ForeColor = Color.Gray;
            label2.ForeColor = Color.Gray;
            label3.ForeColor = Color.Gray;
            switch (DifficultySlider.Value)
            {
                case (1):
                    {
                        label1.ForeColor = Color.Black;
                        break;
                    }
                case (2):
                    {
                        label2.ForeColor = Color.Black;
                        break;
                    }
                case (3):
                    {
                        label3.ForeColor = Color.Black;
                        break;
                    }
            }
        }
        private void ChangeCheckedColour()
        {
            MoveChoice.ForeColor = MoveChoice.Checked == true ? Color.Black : Color.Gray;
        }
        
    }
}
